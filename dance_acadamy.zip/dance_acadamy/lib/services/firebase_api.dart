import 'dart:core';

import 'package:cloud_firestore/cloud_firestore.dart';

var db = FirebaseFirestore.instance;

class FirebaseOperations {
  static userdataadd(
      String mobileNo, String name, String surname, String address) {
    String resp = '';
    final transaction = <String, dynamic>{
      "mobileno": mobileNo,
      "name": name,
      "surname": surname,
      "address": address,
      "tr_dt": DateTime.now().toString(),
    };
    db.collection("academydata").add(transaction).whenComplete(() {
      resp = 'User added successfully';
    });
    //     .catchError((e) {
    //   resp = e.toString();
    // });
    return resp;
  }

  static Stream<QuerySnapshot> fetchuserdata() {
    CollectionReference transaction = db.collection("academydata");
    return transaction.snapshots();
  }
}
