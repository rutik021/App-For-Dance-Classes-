import 'package:dance_acadamy/screen/all_acadamy.dart';
import 'package:dance_acadamy/screen/master_screen.dart';
import 'package:dance_acadamy/theme/color.dart';
import 'package:flutter/material.dart';
// import 'package:fire_flutter_app_test/screens/root_app.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

// Import the screen you want to navigate to

class SplashScreen extends StatelessWidget {
  final box = GetStorage();
  bool get islogged => box.read('islogged') ?? false;
  // bool islogged = false;
  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 2), () {
      if (islogged == true) {
        Get.offAll(DanceAcademicsScreen());
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  MasterScreen()), // Replace NewScreen() with your screen widget
        );
      }
    });

    return Scaffold(
      backgroundColor: AppColor.primary,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Dance Acedemy',
              style: TextStyle(
                color: AppColor.mainColor,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20),
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppColor.secondary),
            ),
          ],
        ),
      ),
    );
  }
}
