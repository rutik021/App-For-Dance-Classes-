import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../theme/color.dart';
import 'login_screen.dart';

class DanceAcademyDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> academyDetails;

  DanceAcademyDetailsScreen({
    Key? key,
    required this.academyDetails,
  }) : super(key: key);

  // final Map<String, dynamic> academyDetails = {
  //   "name": "Maniax Dance Academy",
  //   "address": "Patria Suites Hotel air Port, Rajkot",
  //   "call": "2566958542",
  //   "image": "assets/images/image1.jpeg",
  // };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Academy Details'),
        backgroundColor: AppColor.appBarColor,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              academyDetails['image'],
              width: MediaQuery.of(context).size.width,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16.0),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    academyDetails['name'],
                    style: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                      color: AppColor.textColor,
                    ),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    academyDetails['address'],
                    style: TextStyle(
                      fontSize: 16.0,
                      color: AppColor.labelColor,
                    ),
                  ),
                  SizedBox(height: 16.0),
                  Text(
                    'Call: ${academyDetails['call']}',
                    style: TextStyle(
                      fontSize: 16.0,
                      color: AppColor.primary,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.0),
            Center(
              child: TextButton(
                onPressed: () {
                  // Add your logic here for the 'Book Now' button
                  Get.offAll(LoginScreen());
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(builder: (context) => LoginScreen()),
                  // );
                },
                child: Text(
                  'Book Now',
                  style: TextStyle(
                    fontSize: 18.0,
                    color: Colors.white,
                  ),
                ),
                style: ButtonStyle(
                  backgroundColor:
                      MaterialStateProperty.all<Color>(AppColor.primary),
                  padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
                    EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
                  ),
                  // You can customize other button properties here
                ),
              ),
            ),
            SizedBox(height: 16.0),
          ],
        ),
      ),
      backgroundColor: AppColor.appBgColor,
    );
  }
}
