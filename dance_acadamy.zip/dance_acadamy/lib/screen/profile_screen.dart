import 'package:flutter/material.dart';
import '../theme/color.dart'; // Assuming color.dart file path

class ProfileScreen extends StatelessWidget {
  final String userName = 'Rutik Parmar';
  final String userEmail = 'rutikparmar12@gmail.com';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        backgroundColor: AppColor.appBarColor,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50.0,
              backgroundColor: AppColor.primary,
              child: Icon(Icons.person, size: 60.0, color: Colors.white),
            ),
            SizedBox(height: 16.0),
            Text(
              userName,
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
                color: AppColor.textColor,
              ),
            ),
            SizedBox(height: 8.0),
            Text(
              userEmail,
              style: TextStyle(
                fontSize: 16.0,
                color: AppColor.labelColor,
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                // Add functionality for the edit button
              },
              child: Text(
                'Edit Profile',
                style: TextStyle(color: Colors.white),
              ),
              style: ElevatedButton.styleFrom(
                primary: AppColor.primary,
                padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
