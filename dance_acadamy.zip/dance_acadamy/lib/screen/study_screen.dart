import 'package:flutter/material.dart';
import '../theme/color.dart'; // Assuming color.dart file path

class StudyMaterialScreen extends StatelessWidget {
  final List<String> videoLinks = [
    'https://www.youtube.com/watch?v=video1',
    'https://www.youtube.com/watch?v=video2',
    'https://www.youtube.com/watch?v=video3',
    // Add more video links as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Study Material'),
        backgroundColor: AppColor.appBarColor,
      ),
      body: ListView.builder(
        itemCount: videoLinks.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.video_library, color: AppColor.primary),
            title: Text(
              'Video ${index + 1}',
              style: TextStyle(
                color: AppColor.textColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              videoLinks[index],
              style: TextStyle(color: AppColor.labelColor),
            ),
            onTap: () {
              // Handle tapping on video link
              // For example: launchURL(videoLinks[index]);
            },
          );
        },
      ),
    );
  }
}
