import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../appdata/data.dart';
import '../theme/color.dart';
import 'academy_detail.dart';

class DanceAcademicsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dance Academics'),
        // Use the app bar color from AppColor
        backgroundColor: AppColor.appBarColor,
      ),
      body: Container(
        color: AppColor.appBgColor, // Set the background color
        padding: EdgeInsets.all(8.0), // Add padding around the list
        child: ListView.builder(
          itemCount: academies.length,
          itemBuilder: (context, index) {
            return Card(
              // Use a single background color for all cards
              color: AppColor.cardColor,
              margin: EdgeInsets.symmetric(vertical: 4.0),
              child: ListTile(
                title: Text(
                  academies[index]["name"],
                  style: TextStyle(
                    color: AppColor.textColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                // Add onTap functionality if needed
                onTap: () {
                  // Handle tap actions if required
                  Get.to(DanceAcademyDetailsScreen(
                    academyDetails: {
                      "name": academies[index]["name"],
                      "address": academies[index]["address"],
                      "call": academies[index]["call"],
                      "image": academies[index]["image"]
                    },
                  ));
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //       builder: (context) => DanceAcademyDetailsScreen()),
                  // );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
