List academies = [
  {
    "id": 1,
    "name": "Maniax Dance academy",
    "address": "Patria Suites Hotel air Port,Rajkot",
    "call": "2566958542",
    "image": "assets/images/image2.jpeg",
  },
  {
    "id": 2,
    "name": "Super Dancing class",
    "address": "university Road,Rajkot",
    "call": "8686594585",
    "image": "assets/images/image1.jpeg",
  },
  {
    "id": 3,
    "name": "Beatz Dance Academy",
    "address": "Patria Suites Hotel air Port,Rajkot",
    "call": "2566958542",
    "image": "assets/images/image3.jpeg",
  },
  {
    "id": 4,
    "name": "Dev Group Dandiya Rass classes",
    "address": "Patria Suites Hotel air Port,Rajkot",
    "call": "2566958542",
    "image": "assets/images/image4.jpeg",
  },
  {
    "id": 5,
    "name": "Vertex Dance Studio",
    "address": "Patria Suites Hotel air Port,Rajkot",
    "call": "2566958542",
    "image": "assets/images/image5.jpeg",
  },
];
